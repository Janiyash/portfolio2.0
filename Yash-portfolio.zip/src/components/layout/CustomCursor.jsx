import { useEffect, useRef, useState } from "react";

function isFinePointer() {
  return typeof window !== "undefined" && !window.matchMedia("(pointer: coarse)").matches;
}

export default function CustomCursor() {
  const dotRef = useRef(null);
  const ringRef = useRef(null);
  const [enabled] = useState(isFinePointer);
  const [label, setLabel] = useState("");

  useEffect(() => {
    if (!enabled) return;
    document.body.classList.add("custom-cursor-active");

    let mouseX = 0, mouseY = 0, ringX = 0, ringY = 0, raf;

    const onMove = (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      if (dotRef.current) {
        dotRef.current.style.left = mouseX + "px";
        dotRef.current.style.top = mouseY + "px";
      }
    };

    const animateRing = () => {
      ringX += (mouseX - ringX) * 0.16;
      ringY += (mouseY - ringY) * 0.16;
      if (ringRef.current) {
        ringRef.current.style.left = ringX + "px";
        ringRef.current.style.top = ringY + "px";
      }
      raf = requestAnimationFrame(animateRing);
    };

    const resolveState = (el) => {
      const cursorAttr = el.closest("[data-cursor]");
      if (cursorAttr) return cursorAttr.getAttribute("data-cursor");
      if (el.closest("a, button, [data-hover]")) return "hover";
      return null;
    };

    const onOver = (e) => {
      const state = resolveState(e.target);
      if (!state) {
        ringRef.current?.classList.remove("hovered", "label");
        setLabel("");
        return;
      }
      if (state === "hover") {
        ringRef.current?.classList.add("hovered");
        ringRef.current?.classList.remove("label");
        setLabel("");
      } else {
        ringRef.current?.classList.add("label");
        ringRef.current?.classList.remove("hovered");
        setLabel(state.toUpperCase());
      }
    };

    const onOut = (e) => {
      if (!resolveState(e.relatedTarget instanceof Element ? e.relatedTarget : document.body)) {
        ringRef.current?.classList.remove("hovered", "label");
        setLabel("");
      }
    };

    document.addEventListener("mousemove", onMove);
    document.addEventListener("mouseover", onOver);
    document.addEventListener("mouseout", onOut);
    raf = requestAnimationFrame(animateRing);

    return () => {
      document.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseover", onOver);
      document.removeEventListener("mouseout", onOut);
      document.body.classList.remove("custom-cursor-active");
      cancelAnimationFrame(raf);
    };
  }, [enabled]);

  if (!enabled) return null;

  return (
    <>
      <div ref={dotRef} className="cursor-dot" />
      <div ref={ringRef} className="cursor-ring">
        {label}
      </div>
    </>
  );
}
