import { motion } from "framer-motion";
import { FaGithub } from "react-icons/fa";
import SectionHeading from "../ui/SectionHeading";
import HudCorners from "../ui/HudCorners";
import { projects } from "../../data/projects";

function StatsStrip() {
  const total = projects.length;
  const fullStack = projects.filter((p) =>
    p.tech.some((t) => /node|prisma|firebase|supabase|mysql|php/i.test(t))
  ).length;
  const payments = projects.filter((p) => p.tech.some((t) => /stripe/i.test(t))).length;

  const stats = [
    { label: "Projects", value: total },
    { label: "Full-stack", value: fullStack },
    { label: "Payment integrations", value: payments },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      className="grid grid-cols-3 gap-4 mb-12"
    >
      {stats.map((s) => (
        <div key={s.label} className="hud-panel text-center py-4 px-3">
          <div className="font-display font-black text-2xl text-[--brass]">{s.value}</div>
          <div className="font-mono-label text-[9px] uppercase tracking-wider text-[--text-lo] mt-1">
            {s.label}
          </div>
        </div>
      ))}
    </motion.div>
  );
}

function FeaturedProject({ p }) {
  const breakdown = [
    { label: "Problem", text: p.problem },
    { label: "Approach", text: p.approach },
    { label: "Result", text: p.result },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 32 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      className="mb-12"
    >
      <div
        className="relative shine hud-panel project-card p-8"
        style={{ borderColor: p.accent, "--accent": p.accent }}
      >
          <HudCorners />
          <div className="flex items-start justify-between mb-6">
            <div>
              <span className="font-mono-label text-[10px] uppercase tracking-wider" style={{ color: p.accent }}>
                Featured
              </span>
              <h3 className="font-display font-black text-2xl text-[--text-hi] mt-1">{p.title}</h3>
            </div>
            <span
              className="px-2.5 py-1 text-[9px] font-mono-label uppercase tracking-wider border"
              style={{ color: p.accent, borderColor: p.accent }}
            >
              {p.category}
            </span>
          </div>

          <div className="grid sm:grid-cols-3 gap-5 mb-6">
            {breakdown.map((b) => (
              <div key={b.label}>
                <p className="font-mono-label text-[9px] uppercase tracking-wider text-[--text-lo]/70 mb-1.5">
                  // {b.label}
                </p>
                <p className="text-[--text-lo] text-sm leading-relaxed">{b.text}</p>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap gap-2 mb-7">
            {p.tech.map((t) => (
              <span key={t} className="tech-chip text-[10px] font-mono-label text-[--text-lo] border border-[--hair] px-2 py-1">
                {t}
              </span>
            ))}
          </div>

          <div className="flex gap-3">
            <a
              href={p.github}
              target="_blank"
              rel="noopener noreferrer"
              data-cursor="view project"
              className="inline-flex items-center gap-2 px-5 py-2.5 border text-xs font-mono-label uppercase tracking-wider"
              style={{ borderColor: p.accent, color: p.accent }}
            >
              <FaGithub className="text-sm" />
              View Code
              <span className="cta-arrow">&rarr;</span>
            </a>
            {p.demo && (
              <a
                href={p.demo}
                target="_blank"
                rel="noopener noreferrer"
                data-cursor="live demo"
                className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-mono-label uppercase tracking-wider font-bold text-[--on-accent]"
                style={{ background: p.accent }}
              >
                Live Demo
              </a>
            )}
          </div>
        </div>
    </motion.div>
  );
}

export default function Projects() {
  const featured = projects.find((p) => p.featured) ?? projects[0];
  const rest = projects.filter((p) => p !== featured);

  return (
    <section id="projects" className="relative py-28 overflow-hidden bg-[--void] border-b border-[--hair]">
      <div className="grid-pattern absolute inset-0 opacity-[0.08] pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-6">
        <SectionHeading eyebrow="Selected Work" title="My" accent="Projects" subtitle="Real-world applications, built end to end." index="04" />

        <StatsStrip />

        <FeaturedProject p={featured} />

        <div className="grid md:grid-cols-2 gap-6 mb-16">
          {rest.map((p, index) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.06 }}
              viewport={{ once: true }}
            >
              <div
                className="relative shine hud-panel project-card h-full p-7 flex flex-col"
                style={{ "--accent": p.accent }}
              >
                <HudCorners />
                <div className="flex items-start justify-between mb-5">
                    <div>
                      <span className="proj-num font-mono-label text-lg" style={{ color: p.accent }}>{p.num}</span>
                      <h3 className="font-display font-black text-xl text-[--text-hi] mt-1">{p.title}</h3>
                    </div>
                    <span
                      className="px-2.5 py-1 text-[9px] font-mono-label uppercase tracking-wider border"
                      style={{ color: p.accent, borderColor: p.accent }}
                    >
                      {p.category}
                    </span>
                  </div>

                  <p className="text-[--text-lo] text-sm leading-relaxed mb-3 flex-1">{p.description}</p>
                  <p className="text-[--text-lo]/60 text-xs italic mb-6 font-mono-label">// {p.problem}</p>

                  <div className="flex flex-wrap gap-2 mb-6">
                    {p.tech.map((t) => (
                      <span key={t} className="tech-chip text-[10px] font-mono-label text-[--text-lo] border border-[--hair] px-2 py-1">
                        {t}
                      </span>
                    ))}
                  </div>

                  <div className="flex gap-3">
                    <a
                      href={p.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      data-cursor="view project"
                      className="inline-flex items-center gap-2 px-5 py-2.5 border text-xs font-mono-label uppercase tracking-wider"
                      style={{ borderColor: p.accent, color: p.accent }}
                    >
                      <FaGithub className="text-sm" />
                      View Code
                      <span className="cta-arrow">&rarr;</span>
                    </a>
                    {p.demo && (
                      <a
                        href={p.demo}
                        target="_blank"
                        rel="noopener noreferrer"
                        data-cursor="live demo"
                        className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-mono-label uppercase tracking-wider font-bold text-[--on-accent]"
                        style={{ background: p.accent }}
                      >
                        Live Demo
                      </a>
                    )}
                  </div>
                </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <a
            href="https://github.com/Janiyash"
            target="_blank"
            rel="noopener noreferrer"
            data-cursor="github"
            className="shine inline-flex items-center gap-3 px-10 py-4 bg-[--brass] text-[--on-accent] text-sm font-mono-label uppercase tracking-widest font-bold"
          >
            <FaGithub className="text-xl" />
            View All Projects on GitHub
          </a>
        </motion.div>
      </div>
    </section>
  );
}