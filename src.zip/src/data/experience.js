export const experience = [
  {
    id: "webideal",
    role: "Full Stack Developer Intern",
    company: "WebIdeal Software Solutions",
    location: "Remote",
    period: "2026 — Present",
    current: true,
    summary:
      "Working across the frontend and backend of production web applications at an AI-first SaaS company building a hiring ecosystem (ATS, Recruitment CRM, HRMS, and Job Portals) — primarily within a React and Node.js environment.",
    responsibilities: [
      "Building responsive, accessible frontend interfaces",
      "Developing backend logic and REST API integrations",
      "Working with databases and data models",
      "Collaborating with product, design, and engineering",
      "Contributing to AI and automation-driven features",
      "Testing, debugging, and shipping product enhancements",
    ],
  },
];

export const education = [
  {
    id: "university",
    title: "B.Tech, Computer Science & Engineering",
    place: "ITM (SLS) Baroda University",
    period: "2023 — 2027",
  },
  {
    id: "school",
    title: "Higher Secondary, Science",
    place: "Shreyas Vidhyalaya",
    period: "2021 — 2022",
  },
];
